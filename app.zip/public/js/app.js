/*! populate.js v1.0.2 by @dannyvankooten | MIT license */
;(function(root) {

    /**
     * Populate form fields from a JSON object.
     *
     * @param form object The form element containing your input fields.
     * @param data array JSON data to populate the fields with.
     * @param basename string Optional basename which is added to `name` attributes
     */
    var populate = function( form, data, basename) {

        for(var key in data) {

            if( ! data.hasOwnProperty( key ) ) {
                continue;
            }

            var name = key;
            var value = data[key];

                        if ('undefined' === typeof value) {
                            value = '';
                        }

                        if (null === value) {
                            value = '';
                        }

            // handle array name attributes
            if(typeof(basename) !== "undefined") {
                name = basename + "[" + key + "]";
            }

            if(value.constructor === Array) {
                name += '[]';
            } else if(typeof value == "object") {
                populate( form, value, name);
                continue;
            }

            // only proceed if element is set
            var element = form.elements.namedItem( name );
            if( ! element ) {
                continue;
            }

            var type = element.type || element[0].type;

            switch(type ) {
                default:
                    element.value = value;
                    break;

                case 'radio':
                case 'checkbox':
                    for( var j=0; j < element.length; j++ ) {
                        element[j].checked = ( value.indexOf(element[j].value) > -1 );
                    }
                    break;

                case 'select-multiple':
                    var values = value.constructor == Array ? value : [value];

                    for(var k = 0; k < element.options.length; k++) {
                        element.options[k].selected |= (values.indexOf(element.options[k].value) > -1 );
                    }
                    break;

                case 'select':
                case 'select-one':
                    element.value = value.toString() || value;
                    break;
                case 'date':
                        element.value = new Date(value).toISOString().split('T')[0];    
                    break;
            }

        }

    };

    // Play nice with AMD, CommonJS or a plain global object.
    if ( typeof define == 'function' && typeof define.amd == 'object' && define.amd ) {
        define(function() {
            return populate;
        });
    }   else if ( typeof module !== 'undefined' && module.exports ) {
        module.exports = populate;
    } else {
        root.populate = populate;
    }

}(this));
(function() {
    "use strict";

    function App() {
        this.events = {};

        this.environment = {
            debug: true,
            isMobile: function() {
                return (document.body.clientWidth <= 790) ? true : false;
            },

        }

    }

    App.components = {};

    App.prototype.trigger = function(name, data) {
        var app = this;
        var execute = function() {
            var handlers = app.events[name];
            if (!!handlers === false) return;
            handlers.forEach(function(handler) {
                handler.call(this, data);
            });
        }
        return typeof Promise === 'undefined' ? execute() : new Promise(function(resolve, reject) {
            execute();
            resolve();
        });
    };
    App.prototype.on = function(name, handler) {
        var handlers = this.events[name];
        if (!!handlers === false) {
            handlers = this.events[name] = [];
        }
        handlers.push(handler);
    };
    App.prototype.off = function(name, handler) {
        var handlers = events[name];
        if (!!handlers === false) return;
        var handlerIdx = handlers.indexOf(handler);
        handlers.splice(handlerIdx);
    };


    App.components.toggleTable = function(element, app) {
        element.style.cursor = "pointer";
        var id = element.getAttribute("data-table");

        element.addEventListener("click", function(e){
            e.preventDefault();
            element.querySelector(".mi").classList.toggle("mi-keyboard-arrow-down");
            element.querySelector(".mi").classList.toggle("mi-keyboard-arrow-right");
            document.querySelector("#"+id).classList.toggle("hidden");
        });
        
    }

    App.components.sortableList = function(element, app) {

        function monthDate(param) {
          let dateValue  = Date.parse(param)/1000;
          return dateValue;
        }

        var getSortableItemKeys = function(){
            var items = [];
            [].forEach.call(element.querySelectorAll(".list tr:first-child td[class]"), function(item){
                var sortItem = item.className;
                if(item.hasAttribute("data-type") && item.getAttribute("data-type") === "date"){
                    sortItem = {'name':sortItem, 'attr':'data-timestamp'};
                }
                items.push(sortItem);
            });
            return items;
        }

        var options = {
            valueNames: getSortableItemKeys()
        };

        [].forEach.call(element.querySelectorAll("[data-type=date]"), function(dateField){
            dateField.setAttribute('data-timestamp', monthDate(dateField.innerText));
            console.log(dateField);
        });


        var list = new List(element.id, options);

        var searchInput = document.querySelector("#"+element.id+"-search");

        searchInput && searchInput.addEventListener("keyup", function(e){
            list.search(e.target.value);
        });

        list.listContainer.addEventListener("click", function(e){
            if(e.target.classList.contains("sort")){
                var current = list.listContainer.querySelector(".sort-active:not([data-sort="+e.target.getAttribute("data-sort")+"])");
                current && current.classList.remove("sort-active");
                e.target.classList.toggle("sort-active");
            }
        });



        [].forEach.call(element.querySelectorAll("[data-due-to]"), function(dateField){
            var dueTo = Date.parse(dateField.innerText) + (14 * 24 * 60 * 60 * 60);
            var now = Date.now(); 
            if(now > dueTo){
                dateField.innerHTML = '<span class="due-to-date"> ' + dateField.innerText + '</span>';
            }
        });

    };


   


    App.components.confirmBtn = function(element, app) {
        element.addEventListener("click", function(e){
            if(!confirm(element.getAttribute("data-message"))) {
            e.preventDefault();
            }
        });
    };

    App.components.form = function(element, app) {

        element.classList.contains("edit-form") && [].forEach.call(element.querySelectorAll("[name]"), function(input){
            var el = document.createElement("div");
            el.classList.add("form__row-title");
            el.innerText = input.getAttribute("placeholder");
            input.parentNode.parentNode.insertBefore(el, input.parentNode);
        });

        populate(element, postData);
    };

    App.components.datepicker = function(element, app) {

        function addZ(n){
            return n<10? '0'+n:''+n;
        }
        function parseDate(dateString){
                const parts = dateString.split('/');
                const month = parseInt(parts[0], 10) - 1;
                const day = parseInt(parts[1], 10);
                const year = parseInt(parts[2], 10);
                return new Date(year, month, day);
        }

        var picker = new Pikaday({
            field: element,
            format: 'MM/DD/YYYY',
            toString: function(date, format) {
                const day = addZ(date.getDate());
                const month = addZ(date.getMonth() + 1);
                const year = date.getFullYear();
                return month + '/' + day + '/' + year;
            },
            parse: function(dateString, format) {
                return parseDate(dateString);
            }
        });
   

    };


    App.components.dashboardNav = function(element, app) {

        var stateHandler = function() {
            if (document.body.clientWidth < 1320) {
                element.classList.add("dashboard__nav--compact");
            } else {
                element.classList.remove("dashboard__nav--compact");
            }
        };

        app.on("window:resize", function() {
            stateHandler();
        });

        stateHandler();
    };


    App.components.body = function(element, app) {

        element.classList.remove("no-js");

        var stateHandler = function() {
            if (app.environment.isMobile()) {
                element.classList.remove("desktop");
                element.classList.add("mobile");
            } else {
                element.classList.remove("mobile");
                element.classList.add("desktop");
            }
        };

        app.on("window:resize", function() {
            stateHandler();
        });

        stateHandler();
    };

    App.prototype.init = function(context) {

        var elements = context.querySelectorAll("[data-js]");


        [].forEach.call(elements, function(element) {
            var c = element.getAttribute('data-js');
            c = c.replace(/-([a-z])/g, function(g) { return g[1].toUpperCase(); });
            if (App.components[c]) {
                App.components[c](element, this);
            } else {
                console.log('module not registered!');
            }
        }.bind(this));

        window.addEventListener('resize', function() {
            this.trigger('window:resize');
        }.bind(this));

        window.addEventListener('scroll', function() {
            this.trigger('window:scroll');
        }.bind(this));

    }

    window.App = App;
}());