<?php

namespace App\Middleware;

class RedirectIfNotAuthenticated
{

    protected $redirectTo = '/';


    public function __invoke($request, $response, $next)
    {

        if (!isset($_SESSION['user_id'])) {
            return redirect($this->redirectTo);
        }

        return $next($request, $response);
    }
}
