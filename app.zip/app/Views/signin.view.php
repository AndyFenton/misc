<?php $this->layout('layouts/default', ['title' => 'Sign In'])?>

<style>
.box--login{
    position: absolute;
    min-width: 420px;
    top: 40%;
    left: 50%;
    transform: translateX(-50%) translateY(-50%);
}
.box--login .btn{
    width: 100%;
}
.mobile .box--login{
    top: 20%;
    min-width: 90%;
    transform: translateX(-50%);
}
</style>


<div class="box box--login">
    <div class="box__header">
        <div class="box__header-circle">
            <img src="/img/logo.png" alt=""/>
        </div>
        <h4>Sign in</h4>
    </div>
    <div class="box__wrapper">
        <?=$this->insert('partials/form-messages')?>
        <form action="" method="post" data-js="form">
            <div class="form">
                <div class="form__row">
                    <div class="field">
                        <input type="text" name="user[login]" placeholder="Login" autocomplete="off"/>
                    </div>
                </div>
                <div class="form__row">
                    <div class="field">
                        <input type="password" name="user[password]" placeholder="Password" autocomplete="off"/>
                    </div>
                </div>

                <div class="form__row">
                    <button class="btn">Sign In</button>
                </div>

            </div>
        </form>


    </div>
</div>
