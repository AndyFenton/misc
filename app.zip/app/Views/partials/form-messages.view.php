<?php
if (isset($form_errors)): ?>
<div class="form__message form__message--error">
    <ul>
        <?php foreach ($form_errors as $error): ?>
            <li><?=$error?></li>
        <?php endforeach;?>
    </ul>
</div>
<?php endif;?>
<?php
if (isset($form_messages)): ?>
<div class="form__message form__message--info">
    <ul>
        <?php foreach ($form_messages as $message): ?>
            <li><?=$message?></li>
        <?php endforeach;?>
    </ul>
</div>
<?php endif;?>