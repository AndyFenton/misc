        <div class="dashboard__nav" data-js="dashboard-nav">

            <nav class="nav">
                <a href="/dashboard/users/" class="nav__item <?=pathclass('/dashboard/users/*/', "nav__item--active")?>">
                    <img src="/img/users-white.svg" alt="" />
                    <span>Users</span>
                </a>
                <a href="/dashboard/private/" class="nav__item <?=pathclass('/dashboard/private/*/', "nav__item--active")?>">
                    <img src="/img/private-white.svg" alt="" />
                    <span>Private Parking</span>
                </a>
                <a href="/dashboard/street/" class="nav__item <?=pathclass('/dashboard/street/*/', "nav__item--active")?>">
                    <img src="/img/street-white.svg" alt="" />
                    <span>Street Parking</span>
                </a>
                <a href="/dashboard/map/" class="nav__item <?=pathclass('/dashboard/map/*/', "nav__item--active")?>">
                    <img src="/img/map-white.svg" alt="" />
                    <span>Map</span>
                </a>
            </nav>

        </div>