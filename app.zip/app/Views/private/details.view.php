<?php $this->layout('layouts/default', ['title' => 'Dashboard - Private Parking Details'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Private Parking Details</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/private-white.svg" alt="" />
                    </div>
                    <h4><?=$pp['userId']?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                   <!--  <div class="box__header-item box__header-item--right">
                        <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
                        <a href="delete/" data-js="confirm-btn" data-message="Are you sure? All truck related data like trips and expenses will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                    </div> -->
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <div class="box__wrapper grid" style="padding-bottom:0;">

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>UserId</h6>
                                <span><a href="/dashboard/users/<?=$pp['userId']?>/" class="link"><?=$pp['userId']?></a></span>
                            </div>
                            <div class="item-info">
                                <h6>accountId</h6>
                                <span><?=$pp['accountId']?></span>
                            </div>
                            <div class="item-info">
                                <h6>EndDate</h6>
                                <span>
                                    <?php
                                                    $timestamp=date_create($pp['endDate']);
                                                    $timestamp = date_format($timestamp,"m.d.Y H:i");
                                                    echo $timestamp;
                                                    ?>

                                </span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>active</h6>
                                <span><?=(($pp['active']==1) ? 'YES' : 'NO')?></span>
                            </div>
                            <div class="item-info">
                                <h6>available current</h6>
                                <span><?=$pp['available']?></span>
                            </div>
                            <div class="item-info">
                                <h6>available total</h6>
                                <span><?=$pp['numberOfCars']?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Image</h6>
                                <span><a href="<?=$pp['img']?>" class="link" target="_blank">Open</a></span>
                            </div>
                            <div class="item-info">
                                <h6>Location</h6>
                                <span><a href="https://maps.google.com?q=<?=$pp['lat']?>,<?=$pp['lon']?>" class="link" target="_blank"><?=$pp['lat']?>,<br/><?=$pp['lon']?></a></span>
                            </div>
                        </div>


                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>price</h6>
                                <span><?=$pp['price']?></span>
                            </div>
                            <div class="item-info">
                                <h6>special</h6>
                                <span><?=$pp['special']?></span>
                            </div>
                            <div class="item-info">
                                <h6>type</h6>
                                <span><?=$pp['type']?></span>
                            </div>

                        </div>


              

                    </div>


<div class="box__wrapper grid" style="padding-bottom:0;">


                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                                           <div class="item-info">
                                                <h6 data-table="accept">ACCEPT</h6>
                                            </div>
                        </div>


                    </div>
                        <div class="table" id="accept">
                            <div class="field">
                            <input id="ppaccept-list-search" type="text" placeholder="Search" autocomplete="off" />
                            </div>
                            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                            <table class="table__item" id="ppaccept-list" data-js="sortable-list">
                                <tr class="no-user-select">
                                    <th class="sort" data-sort="sender">Sender<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="driverCurrentCar">driverCurrentCar<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="driverUserId">driverUserId<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="location">Driver User Location<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="startTime">startTime<i class="mi mi-unfold-more"></i></th>
                                </tr>
                                <tbody class="list">
                                <?php foreach ($pp_accept as $sender => $accept): ?>
                                    <tr class="<?=(!empty($accept['startTime']) ? 'green' : 'yellow')?>">
                                        <td class="sender">
                                            <a href="/dashboard/users/<?=$sender?>/" class="link"><?=$sender?></a>
                                        </td>
                                        <td class="driverCurrentCar">
                                            <?=$accept['driverCurrentCar']?>
                                        </td>
                                        <td class="driverUserId">
                                            <?=$accept['driverUserId']?>
                                        </td>
                                        
                                        <td class="location">
                                            <a href="https://maps.google.com?q=<?=$accept['driverUserLatitude']?>,<?=$accept['driverUserLongitude']?>" class="link" target="_blank"><?=$accept['driverUserLatitude']?>, <?=$accept['driverUserLongitude']?></a>
                                        </td>
                                        <td class="startTime" data-type="date">
                                            <?php
                                                    if(!empty($accept['startTime'])){
                                                    $timestamp=date_create($accept['startTime']);
                                                    $timestamp = date_format($timestamp,"m.d.Y H:i");
                                                    echo $timestamp;
                                                }else{
                                                    echo '-';
                                                    
                                                }
                                                ?>
                                        </td>
                                    </tr>
                                    <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>


        </div>
    </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>