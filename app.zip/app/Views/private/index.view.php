<?php $this->layout('layouts/default', ['title' => 'Dashboard - Private Parking'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Private Parking</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/private-white.svg" alt="" />
                    </div>
                    <h4>Private Parking</h4>
                    <!-- <div class="box__header-item box__header-item--right">
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div> -->
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="pp-list-search" type="text" placeholder="Search" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($private_parking)): ?>
                        <span class="box__message">No private parking</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="pp-list" data-js="sortable-list">
                                    <tr class="no-user-select">
                                        <th>&nbsp;</th>
                                        <th class="sort" data-sort="userId">UserID<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="accountId">accountId<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="available">Available Current<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="numberOfCars">Available Total<i class="mi mi-unfold-more"></i></th>
                                        
                                        <th class="sort " data-sort="endDate">endDate<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort">img</th>
                                        <th class="sort" data-sort="location">location<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="price">price<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="special">special<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="type">type<i class="mi mi-unfold-more"></i></th>
                                        
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($private_parking as $user_id => $data): ?>
                                            <tr class="<?=(($data['active']==0) ? 'red' : 'green')?>">

                                                <td><a href="<?=$user_id?>/" class="link">Details</a></td>
                                                <td class="userId">
                                                    <a href="/dashboard/users/<?=$user_id?>/" class="link"><?=$user_id?></a>
                                                </td>
                                                <td class="accountId">
                                                    <?=$data['accountId']?>
                                                </td>
                                                <td class="available">
                                                    <?=$data['available']?>
                                                </td>
                                                <td class="numberOfCars">
                                                    <?=$data['numberOfCars']?>
                                                </td>
                                                <td class="endDate" data-type="date">
                                                    <?php
                                                    $timestamp=date_create($data['endDate']);
                                                    $timestamp = date_format($timestamp,"m.d.Y H:i");
                                                    echo $timestamp;
                                                    ?>
                                                </td>
                                                <td class="img">
                                                    <a href="<?=$data['img']?>" class="link" target="_blank">Open</a>
                                                </td>
                                                <td class="location">
                                                    <a href="https://maps.google.com?q=<?=$data['lat']?>,<?=$data['lon']?>" class="link" target="_blank"><?=$data['lat']?>, <?=$data['lon']?></a>
                                                </td>
                                                <td class="price">
                                                    <?=$data['price']?>
                                                </td>
                                                <td class="special">
                                                    <?=$data['special']?>
                                                </td>
                                                <td class="type">
                                                    <?=$data['type']?>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>