<?php $this->layout('layouts/default', ['title' => 'Dashboard - User Details'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">User Details</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <h4><?=$user['id']?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                   <!--  <div class="box__header-item box__header-item--right">
                        <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
                        <a href="delete/" data-js="confirm-btn" data-message="Are you sure? All truck related data like trips and expenses will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                    </div> -->
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <div class="box__wrapper grid" style="padding-bottom:0;">

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>accountId</h6>
                                <span><?=$user['accountId']?></span>
                            </div>
                            <div class="item-info">
                                <h6>customerId</h6>
                                <span><?=$user['customerId']?></span>
                            </div>
                            <div class="item-info">
                                <h6>phoneNumber</h6>
                                <span><?=$user['phoneNumber']?></span>
                            </div>
                            <div class="item-info">
                                <h6>shareBalance</h6>
                                <span><?=$user['shareBalance']?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>username</h6>
                                <span><?=$user['username']?></span>
                            </div>
                            <div class="item-info">
                                <h6>email</h6>
                                <span><?=$user['email']?></span>
                            </div>
                            <div class="item-info">
                                <h6>password</h6>
                                <span><?=$user['password']?></span>
                            </div>
                            
                            
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>firstCar
                                    <?php if($user['currentCar']==1): ?>
                                        <b>&bull;</b>
                                    <?php endif; ?>
                                </h6>
                                <span><?=$user['firstCar']?></span>
                            </div>
                            <div class="item-info">
                                <h6>firstCarNumberType</h6>
                                <span><?=$user['firstCarNumberType']?></span>
                            </div>
                            <div class="item-info">
                                <h6>firstCarSize</h6>
                                <span><?=$user['firstCarSize']?></span>
                            </div>
                        </div>


                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>secondCar
                                <?php if($user['currentCar']==2): ?>
                                        <b>&bull;</b>
                                    <?php endif; ?></h6>
                                <span><?=$user['secondCar']?></span>
                            </div>
                            <div class="item-info">
                                <h6>secondCarNumberType</h6>
                                <span><?=$user['secondCarNumberType']?></span>
                            </div>
                            <div class="item-info">
                                <h6>secondCarSize</h6>
                                <span><?=$user['secondCarSize']?></span>
                            </div>

                        </div>


                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                                           <div class="item-info">
                                                <h6 data-js="toggle-table" data-table="urh"><i class="mi mi-keyboard-arrow-right"></i>Rate History</h6>
                                            </div>
                        </div>


                    </div>


                        <div class="table hidden" id="urh">
                            <div class="field">
                            <input id="rate-history-list-search" type="text" placeholder="Search" autocomplete="off" />
                            </div>
                            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                            <table class="table__item" id="rate-history-list" data-js="sortable-list">
                                <tr class="no-user-select">
                                    <th class="sort" data-sort="date">Date<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort">Sender</th>
                                    <th class="sort">Message</th>
                                </tr>
                                <tbody class="list">
                                <?php foreach ($user['rateHistory'] as $rate): ?>
                                    <tr>
                                        <td class="date" data-type="date">
                                            <?=$rate['date']?>
                                        </td>
                                        <td class="sender">
                                            <a href="/dashboard/users/<?=$rate['sender']?>/" class="link"><?=$rate['sender']?></a>
                                        </td>
                                        <td class="mess">
                                            <?=$rate['mess']?>
                                        </td>
                                    </tr>
                                    <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>


                    <div class="box__wrapper grid" style="padding-bottom:0;">


                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                                           <div class="item-info">
                                                <h6 data-js="toggle-table" data-table="uh"><i class="mi mi-keyboard-arrow-right"></i>History</h6>
                                            </div>
                        </div>


                    </div>
                        <div class="table hidden" id="uh">
                            <div class="field">
                            <input id="history-list-search" type="text" placeholder="Search" autocomplete="off" />
                            </div>
                            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                            <table class="table__item" id="history-list" data-js="sortable-list">
                                <tr class="no-user-select">
                                    <th class="sort" data-sort="date">Date<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="sender">Sender<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="car">Car<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="driverCancel">driverCancel<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="location">Location<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="price">price<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="share">share<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="shareCancel">shareCancel<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="streetName">streetName<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="type">type<i class="mi mi-unfold-more"></i></th>
                                </tr>
                                <tbody class="list">
                                <?php foreach ($user['history'] as $history): ?>
                                    <tr class="<?=(($history['driverCancel'] != '' || $history['shareCancel'] != '') ? 'red' : 'green')?>">
                                        <td class="date" data-type="date">
                                            <?=$history['date']?>
                                        </td>
                                        <td class="sender">
                                            <a href="/dashboard/users/<?=$history['sender']?>/" class="link"><?=$history['sender']?></a>
                                        </td>
                                        <td class="car">
                                            <?=$history['car']?>
                                        </td>
                                        <td class="driverCancel">
                                            <?=(empty($history['driverCancel']) ? "NO" : "YES")?>
                                        </td>
                                        <td class="location">
                                            <a href="https://maps.google.com?q=<?=$history['lat']?>,<?=$history['lon']?>" class="link" target="_blank"><?=$history['lat']?>, <?=$history['lon']?></a>
                                        </td>
                                        <td class="price">
                                            <?=$history['price']?>
                                        </td>
                                        <td class="share">
                                            <?=($history['share'] ?? "-")?>
                                        </td>
                                        <td class="shareCancel">
                                            <?=(empty($history['shareCancel']) ? "NO" : "YES")?>
                                        </td>
                                        <td class="streetName">
                                            <?=$history['streetName']?>
                                        </td>
                                        <td class="type">
                                            <?=$history['type']?>
                                        </td>
                                    </tr>
                                    <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>


    <div class="box__wrapper grid" style="padding-bottom:0;">


                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                                           <div class="item-info">
                                                <h6 data-js="toggle-table" data-table="ue"><i class="mi mi-keyboard-arrow-right"></i>Earnings</h6>
                                            </div>
                        </div>


                    </div>
                        <div class="table hidden" id="ue">
                            <div class="field">
                            <input id="earnings-list-search" type="text" placeholder="Search" autocomplete="off" />
                            </div>
                            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                            <table class="table__item" id="earnings-list" data-js="sortable-list">
                                <tr class="no-user-select">
                                    <th class="sort" data-sort="date">Date<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="sender">Sender<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="car">Car<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="location">Location<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="price">price<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="streetName">streetName<i class="mi mi-unfold-more"></i></th>
                                    <th class="sort" data-sort="userName">userName<i class="mi mi-unfold-more"></i></th>
                                </tr>
                                <tbody class="list">
                                <?php foreach ($user['earnings'] as $earnings): ?>
                                    <tr>
                                        <td class="date" data-type="date">
                                            <?=$earnings['date']?>
                                        </td>
                                        <td class="sender">
                                            <a href="/dashboard/users/<?=$earnings['sender']?>/" class="link"><?=$earnings['sender']?></a>
                                        </td>
                                        <td class="car">
                                            <?=$earnings['car']?>
                                        </td>
                                        
                                        
                                        <td class="location">
                                            <a href="https://maps.google.com?q=<?=$earnings['lat']?>,<?=$earnings['lon']?>" class="link" target="_blank"><?=$earnings['lat']?>, <?=$earnings['lon']?></a>
                                        </td>
                                        <td class="price">
                                            <?=$earnings['price']?>
                                        </td>
                                        <td class="streetName">
                                            <?=$earnings['streetName']?>
                                        </td>
                                        <td class="userName">
                                            <?=$earnings['userName']?>
                                        </td>
                                    </tr>
                                    <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>


        </div>
    </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>