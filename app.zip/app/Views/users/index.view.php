<?php $this->layout('layouts/default', ['title' => 'Dashboard - Users'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Users</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <h4>Users</h4>
                    <!-- <div class="box__header-item box__header-item--right">
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div> -->
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="users-list-search" type="text" placeholder="Search" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($users)): ?>
                        <span class="box__message">No users</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="users-list" data-js="sortable-list">
                                    <tr class="no-user-select">
                                        <th class="sort" data-sort="accountId">accountId<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="username">username<i class="mi mi-unfold-more"></i></th>
                                        
                                        <th class="sort" data-sort="email">email<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="currentCar">currentCar<i class="mi mi-unfold-more"></i></th>
                                        
                                        <th class="sort" data-sort="phoneNumber">phoneNumber<i class="mi mi-unfold-more"></i></th>
                                        
                                        <th class="sort" data-sort="shareBalance">shareBalance<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="customerId">customerId<i class="mi mi-unfold-more"></i></th>
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($users as $user_id => $user): ?>
                                            <tr>
                                                <td class="accountId">
                                                    <a href="<?=$user_id?>/" class="link"><?=$user_id?></a>
                                                </td>
                                                <td class="username">
                                                    <?=$user['username']?>
                                                </td>
                                                <td class="email">
                                                    <?=$user['email']?>
                                                </td>
                                                <td class="currentCar">
                                                    <?php if($user['currentCar']==1){
                                                        echo $user['firstCar'];
                                                    }else{
                                                        echo $user['secondCar'];
                                                    }
                                                    ?>
                                                </td>
                                                <td class="phoneNumber">
                                                    <?=$user['phoneNumber']?>
                                                </td>
                                                <td class="shareBalance">
                                                    <?=$user['shareBalance']?>
                                                </td>
                                                <td class="customerId">
                                                    <?=$user['customerId']?>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>