<?php $this->layout('layouts/default', ['title' => 'Dashboard'])?>

    <style>
        .box__header {
            padding-top: 40px;
        }
        
        .box__header-circle {
            width: 60px;
            height: 60px;
            line-height: 60px;
        }
    </style>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Dashboard</h1>
        </div>

        <div class="grid__item grid__item--half">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/truck-white.svg" alt="" />
                    </div>
                    <h4>Trucks</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="/dashboard/trucks/add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                </div>
                <?php if(empty($trucks)): ?>
                    <span class="box__message">No trucks</span>
                    <?php else: ?>
                        <div class="table">
                            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                            <table class="table__item">
                                <thead>
                                    <tr>
                                        <th>№</th>
                                        <th>Truck</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach($trucks as $truck_id => $truck): ?>
                                    <tr>
                                        <td>
                                            <?=$truck_id?>
                                        </td>
                                        <td>
                                            <?=$truck['Make']?>
                                        </td>
                                        <td><a href="/dashboard/trucks/<?=$truck_id?>/" class="link">Details</a></td>
                                    </tr>
                                    <?php endforeach; ?>
                                        <tr>
                                            <td colspan="3"><a href="/dashboard/trucks/" class="link">View all</a></td>
                                        </tr>
                                    </tbody>
                            </table>
                        </div>
                        <?php endif; ?>

            </div>

        </div>

        <div class="grid__item grid__item--half">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/driver-white.svg" alt="" />
                    </div>
                    <h4>Drivers</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="/dashboard/drivers/add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                </div>
                <?php if(empty($drivers)): ?>
                    <span class="box__message">No drivers</span>
                    <?php else: ?>
                        <div class="table">
                            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                            <table class="table__item">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach($drivers as $driver): ?>
                                    <?php if(!$driver['active']) continue; ?>
                                    <?php $driver['slug'] = slugify($driver['Name']) ?>
                                        <tr>
                                            <td>
                                                <?=$driver['Name']?>
                                            </td>
                                            <td>
                                                <?=$driver['Phone']?>
                                            </td>
                                            <td><a href="/dashboard/drivers/<?=$driver['slug']?>/" class="link">Details</a></td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <tr>
                                            <td colspan="3"><a href="/dashboard/drivers/" class="link">View all</a></td>
                                        </tr>
                                    </tbody>
                            </table>
                        </div>
                        <?php endif; ?>

            </div>

        </div>

        <div class="grid__item grid__item--half">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/contract-white.svg" alt="" />
                    </div>
                    <h4>Contracts</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="/dashboard/contracts/add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                </div>
                <?php if(empty($contracts)): ?>
                    <span class="box__message">No contracts</span>
                    <?php else: ?>
                        <div class="table">
                            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                            <table class="table__item">
                                <thead>
                                    <tr>
                                        <th>Company</th>
                                        <th>Starts</th>
                                        <th>Ends</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach($contracts as $contract_company => $contract): ?>
                                    <?php $contract['slug'] = slugify($contract_company) ?>
                                    <tr>
                                        <td>
                                            <?=$contract_company?>
                                        </td>
                                        <td>
                                            <?=$contract['Start']?>
                                        </td>
                                        <td>
                                            <?=$contract['End']?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                            <td colspan="3"><a href="/dashboard/contracts/" class="link">View all</a></td>
                                    </tr>
                                    </tbody>
                            </table>
                        </div>
                        <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>