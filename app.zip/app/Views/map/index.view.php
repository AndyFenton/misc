<?php $this->layout('layouts/default', ['title' => 'Dashboard - Map'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Map</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/map-white.svg" alt="" />
                    </div>
                    <h4>Map</h4>
                </div>




                    <h2 class="coming-soon">Coming soon</h2>

                    <!-- ЗДЕСЬ КОНТЕНТ -->





            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>