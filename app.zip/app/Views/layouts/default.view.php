<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title><?=$this->e($title)?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,400,500,700" rel="stylesheet">

    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    <link href="<?=$this->asset('/css/common.css')?>" rel="stylesheet">
    <link href="<?=$this->asset('/css/main.css')?>" rel="stylesheet">
    <link href="<?=$this->asset('/css/material-icons.min.css')?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/pikaday/css/pikaday.css">
    <!--[if lte IE 9]>
    <script src="/js/classList.js"></script>
    <![endif]-->
<style>
.mi{
    vertical-align: top;
    line-height: inherit !important;
}
</style>
</head>
<!--[if IE 9]>
    <body class="body no-js desktop ie9" data-js="body">
<![endif]-->

<body class="body no-js desktop" data-js="body">
    <div class="body__wrapper">

        <?=$this->section('content')?>

    </div>
    <script src="<?=$this->asset('/js/date.js')?>"></script>
    <script src="<?=$this->asset('/js/app.js')?>"></script>
    <script src="<?=$this->asset('/js/list.min.js')?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/pikaday/pikaday.js"></script>
    <script>
    var app = new App();
    var context = document.documentElement;
    var postData = <?=json_encode($old_input ?? null)?>;
    app.init(context);

    </script>

</body>
</html>