<?php

// Routes

$app->get('/', '\App\Controllers\DashboardController:getSignIn')->add(new \App\Middleware\RedirectIfAuthenticated);
$app->post('/', '\App\Controllers\DashboardController:postSignIn')->add(new \App\Middleware\RedirectIfAuthenticated);

$app->group('/dashboard', function () {

    $this->group('/users', function () {

        $this->get('/', '\App\Controllers\UsersController:getIndex');

        $this->group('/{user_id}', function () {
            
            $this->get('/', '\App\Controllers\UsersController:getDetails');

        });

    });


    $this->group('/private', function () {

        $this->get('/', '\App\Controllers\PrivateParkingController:getIndex');

        $this->group('/{user_id}', function () {
            
            $this->get('/', '\App\Controllers\PrivateParkingController:getDetails');

        });

    });




    $this->get('/map/', '\App\Controllers\MapController:getIndex');
    
    $this->get('/street/', '\App\Controllers\StreetParkingController:getIndex');

    $this->get('/export/', '\App\Controllers\DashboardController:getExport');

    $this->get('/export/{filename}/', '\App\Controllers\DashboardController:getExportFile');

    $this->post('/export/', '\App\Controllers\DashboardController:postExport');


})->add(new \App\Middleware\RedirectIfNotAuthenticated);
