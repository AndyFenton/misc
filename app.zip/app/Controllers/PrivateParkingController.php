<?php

namespace App\Controllers;

use App\Models\PPAccept;
use App\Models\PrivateParking;


class PrivateParkingController extends Controller
{

    public function getIndex($request, $response)
    {
        $private_parking = PrivateParking::all();

        return $this->render('private/index', compact('private_parking'));
        
    }

    public function getDetails($request, $response, $args)
    {
        $pp = PrivateParking::find($args['user_id']);

        $pp_accept = PPAccept::find($args['user_id']);

        if (empty($pp)) {
            return redirect("/dashboard/private");
        }

        $pp['userId'] = $args['user_id'];

        return $this->render('private/details', compact('pp', 'pp_accept'));
    }

    // public function getAdd($request, $response)
    // {
    //     return $this->render('trucks/update');
    // }

    // public function postAdd($request, $response)
    // {
    //     return $this->updateTruckDetails($request);
    // }

    // public function getEdit($request, $response, $args)
    // {
    //     $truck = Truck::find($args['truck_id']);

    //     if (empty($truck)) {
    //         return redirect("/dashboard/trucks");
    //     }

    //     return $this->render('trucks/update', compact('truck'));
    // }

    // public function postEdit($request, $response, $args)
    // {
    //     return $this->updateTruckDetails($request, true);
    // }

    // public function getDelete($request, $response, $args)
    // {
    //     Truck::remove($args['truck_id']);

    //     $this->flash->addMessage('form_messages', ["Truck #${args['truck_id']} has been deleted."]);

    //     return redirect("/dashboard/trucks");
    // }

    // private function updateTruckDetails($request, $edit = false)
    // {
    //     $validator = $this->validate($request, [
    //         "truck.TruckNumber" => "required|numeric",
    //     ]);

    //     if ($validator->failed()) {
    //         return back();
    //     }

    //     $truck = $request->getParam('truck');

    //     $truckNumber = $truck['TruckNumber'];

    //     if ($edit) {

    //         try{
    //             Truck::update($truckNumber, $truck);
    //         }catch(\Throwable $e){
    //             $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
    //             return back();
    //         }

    //     } else {

    //         try{
    //             Truck::create($truckNumber, $truck);
    //         }catch(\Throwable $e){
    //             $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
    //             return back();
    //         }
            
    //     }

    //     if ($edit) {
    //         return redirect("/dashboard/trucks/" . $truck['TruckNumber']);
    //     } else {
    //         return redirect("/dashboard/trucks");
    //     }

    // }

}
