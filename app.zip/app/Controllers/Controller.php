<?php

namespace App\Controllers;

abstract class Controller
{
    public function __construct($c)
    {
        $this->logger = $c['logger'];
        $this->flash = $c['flash'];
        $this->db = $c['firebase']->getDatabase();
        $this->storage = $c['firebase']->getStorage();
        $this->view = $c['view'];
        $this->validator = $c['validator'];
    }

    protected function validate($input, $rules, $aliases = [])
    {
        return $this->validator->validate($input, $rules, $aliases);
    }

    public function render($template, array $data = [])
    {
        return $this->view->render($template, $data);
    }

}
