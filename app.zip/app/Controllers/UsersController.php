<?php

namespace App\Controllers;

use App\Models\User;
use App\Models\History;
use App\Models\Earnings;

class UsersController extends Controller
{

    public function getIndex($request, $response)
    {
        $users = User::all();

        return $this->render('users/index', compact('users'));
        
    }

    public function getDetails($request, $response, $args)
    {
        $user = User::find($args['user_id']);

        if (empty($user)) {
            return redirect("/dashboard/users");
        }

        $user['id'] = $args['user_id'];

        $rateHistory = [];

        if(!empty($user['rateHistory'])){

            foreach($user['rateHistory'] as $date => $rate){
                foreach($rate as $timestamp => $mess){
                    $timestamp=date_create($timestamp);
                    $timestamp = date_format($timestamp,"m.d.Y H:i");
                    $rateHistory[] = ['date' => $timestamp, 'mess' => reset($mess), 'sender' => key($mess)];
                }
            }

        }

        $user['rateHistory'] = $rateHistory;


        $history = [];

        $user_history = History::find($args['user_id']);

        if(!empty($user_history)){

            foreach($user_history as $date => $arr){
                foreach($arr as $timestamp => $data){
                    $timestamp=date_create($timestamp);
                    $timestamp = date_format($timestamp,"m.d.Y H:i");
                    $history[] = array_merge($data, ['date' => $timestamp]);
                }
            }

        }

        $user['history'] = $history;


        $earnings = [];

        $user_earnings = Earnings::find($args['user_id']);

        if(!empty($user_earnings)){

            foreach($user_earnings as $date => $arr){
                foreach($arr as $timestamp => $data){
                    $timestamp=date_create($timestamp);
                    $timestamp = date_format($timestamp,"m.d.Y H:i");
                    $earnings[] = array_merge($data, ['date' => $timestamp]);
                }
            }

        }

        $user['earnings'] = $earnings;

        return $this->render('users/details', compact('user'));
    }

    
}
