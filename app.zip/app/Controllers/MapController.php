<?php

namespace App\Controllers;

class MapController extends Controller
{

    public function getIndex($request, $response)
    {

        return $this->render('map/index');
        
    }

}
