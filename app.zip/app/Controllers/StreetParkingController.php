<?php

namespace App\Controllers;

class StreetParkingController extends Controller
{

    public function getIndex($request, $response)
    {

        return $this->render('street/index');
        
    }

}
