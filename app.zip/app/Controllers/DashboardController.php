<?php

namespace App\Controllers;

use App\Models\Contract;
use App\Models\Driver;
use App\Models\Truck;

class DashboardController extends Controller
{

    public function getSignIn($request, $response)
    {
        return $this->render('signin');
    }

    public function postSignIn($request, $response)
    {

        $validator = $this->validate($request, ["user.login" => "required", "user.password" => "required"],
            ['user.login' => 'User login', 'user.password' => 'User password']);

        if ($validator->failed()) {
            return back();
        }

        $user = $request->getParam('user');

        if ($user['login'] === 'admin' && $user['password'] === 'admin') {
            $_SESSION['user_id'] = 'admin';
            return redirect('/');
        }

        $this->flash->addMessage("form_errors", ["Wrong User login or password"]);
        return back();
    }

    public function getPageNotFound($request, $response)
    {
        return $response->withStatus(404)
            ->withHeader('Content-Type', 'text/html')
            ->write($this->render('404'));
    }

    public function getExport($request, $response)
    {
        $files = [];
        $path = '../storage/backups';
        if(is_dir($path)){
            $files = scandir($path);
            $files = array_diff($files, array('.', '..'));
        }
        return $this->render('export', compact('files'));
    }

    public function getExportFile($request, $response, $args)
    {
        $file    = '../storage/backups/' . $args['filename'] . ".json";

        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.basename($file).'"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            exit;
        }else{
            die("File not found");
        }
    }

    public function postExport($request, $response)
    {
        $ref = $this->db->getReference('/');
        $json = $ref->getValue();
        $json = json_encode($json, JSON_PRETTY_PRINT);
        $filename = "export_" . date("m_d_Y_H_i_s") . ".json";
        file_put_contents('../storage/backups/' . $filename, $json);
        return redirect("/dashboard/export");
    }

}
