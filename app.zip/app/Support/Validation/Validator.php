<?php

namespace App\Support\Validation;

use App\Support\Validation\Contracts\ValidatorInterface;
use Psr\Http\Message\ServerRequestInterface as Request;
use Rakit\Validation\Validator as ValidationEngine;
use Slim\Flash\Messages;

class Validator implements ValidatorInterface
{
    protected $errors = [];
    protected $flash;

    public function __construct(Messages $flash = null)
    {
        $this->flash = $flash;
    }

    public function validate($input, $rules, $aliases = [])
    {
        $validator = new ValidationEngine;
        if ($input instanceof Request) {
            $input = $input->getParams() + ($input->getParsedBody() ?? []);
        }

        $validation = $validator->make($input ?? [], $rules);

        $validation->setAliases($aliases);

        $validation->validate();

        if ($validation->fails()) {
            $this->errors = $validation->errors()->firstOfAll();
            if ($this->flash) {
                $this->flash->addMessage('form_errors', $this->errors);
            }
        }

        return $this;
    }
    public function failed()
    {
        return !empty($this->errors);
    }
    public function errors()
    {
        return $this->errors;
    }
}
