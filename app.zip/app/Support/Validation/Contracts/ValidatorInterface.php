<?php

namespace App\Support\Validation\Contracts;

interface ValidatorInterface
{
    public function validate($input, $rules);
    public function failed();
    public function errors();
}
