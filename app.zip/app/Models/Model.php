<?php

namespace App\Models;

abstract class Model
{

    protected static $_ref = null;

    protected static function _validateModel()
    {

            $subClassName = get_class(new static());

            if (empty(static::$_path)) {
                throw new \Exception($subClassName . '::$_path must be implemented');
            }
            if(isset($_SESSION['archive'])){
                static::$_ref = app('firebase')->getDatabase()->getReference('Archive/' . $_SESSION['archive'] . static::$_path);
            }else{
                static::$_ref = app('firebase')->getDatabase()->getReference(static::$_path);  
            }
            

    }


    private static function query($child = null, $limitToLast = null, $limitToFirst = null)
    {
        static::_validateModel();

        $ref = static::$_ref;

        if($child){
            $ref = $ref->getChild($child);
        }

        if($limitToLast){
            $ref = $ref->limitToLast($limitToLast);
        }

        if($limitToFirst){
            $ref = $ref->limitToFirst($limitToFirst);
        }

        return $ref->orderByKey()->getValue();
    }

    public static function find($child, $limitToLast = null, $limitToFirst = null){
        return static::query($child, $limitToLast, $limitToFirst);
    }

    public static function update($path, $data){

        static::_validateModel();

        $ref = static::$_ref;
        
        $ref = $ref->getChild($path);

        if(empty($ref->getValue())){
            throw new \Exception("");
        }

        return $ref->update($data);

    }

    public static function create($path, $data){

        static::_validateModel();

        $ref = static::$_ref;
        
        if($ref->getSnapshot()->hasChild($path)){
            throw new \Exception("Record with this id already exists");
        }

        return $ref->getChild($path)->set($data);
        
    }

    public static function all()
    {
        return static::query();
    }


    public static function last($num = 1)
    {
        return static::query(null, $num);
    }

    public static function first($num = 1)
    {
        return static::query(null, null, $num);
    }


    public static function remove($child = null){

        static::_validateModel();

        $ref = static::$_ref;

        if($child){
            $ref = $ref->getChild($child);
        }

        return $ref->remove();
    }

}
