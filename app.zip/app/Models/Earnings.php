<?php

namespace App\Models;

class Earnings extends Model
{

    protected static $_path = '/Earnings';

}
