<?php

namespace App\Models;

class History extends Model
{

    protected static $_path = '/History';

}
