<?php

namespace App\Models;

class PrivateParking extends Model
{

    protected static $_path = '/PrivateParking';

}
