<?php

namespace App\Models;

class PPAccept extends Model
{

    protected static $_path = '/PPAccept';

}
